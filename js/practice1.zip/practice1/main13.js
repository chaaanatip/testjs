
let numbers = [1, 1, 3, 8, 21, 8, 13, 3, 8, 7];
// Insert your code here
// return value will be [7, 8, 3, 13, 8, 21, 8, 3, 1, 1]