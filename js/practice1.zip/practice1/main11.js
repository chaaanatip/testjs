// XXXXX : What is you think about result
const arr = [1, 2, 3];
arr.push(4); // arr[1,2,3,4]
arr = [1, 2, 3, 4]; // XXXXX
const obj = { name: 'Alice' };
obj.age = 30; // XXXXX
obj = { name: 'Alice', age: 30 }; // XXXXX
console.log(arr)
console.log(obj)