let a = 5, b=10;
[a,b] = [b,a]
console.log(a)
console.log(b)