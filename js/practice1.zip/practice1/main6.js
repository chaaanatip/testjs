let x = 10;
let y = "20";
let result = x + y;
console.log(result); // 30
console.log(typeof result); // number
