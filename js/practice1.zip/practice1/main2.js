let numString = "1234"
let num = +numString
console.log(typeof num)