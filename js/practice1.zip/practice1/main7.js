let person = {
    name: "John",
    age: 25,
    isStudent: true
};
person.hobbies = ["game","coding"];
person.age = 10
delete person.isStudent
console.log(person)
