let numbers = [34,1,58,8,21,5,13,3,89,7];
function findMin(arr) {
    min = Math.min(...arr)
    return min
}
console.log(findMin(numbers))
