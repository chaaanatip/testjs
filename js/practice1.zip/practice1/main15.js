const numbers = [1, 2, 3, 4, 5];
const [first,second,,,last] = numbers
console.log(first)
console.log(second)
console.log(last)